"use_strict";
m.route.prefix("#");

function sleep (time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

const splash = {
  oncreate: () => {
    sleep(3000).then(() => {
      m.route.set("intro")
    });
  },
  view: () => m("main", [
    m("header","telnetd - backdoor!"),
    m("img",{src:"splash.png"})
    ])
};

const intro = {
  oncreate: () => {
    document.querySelector("a").focus();
  },
  view: () => 
    m("main", [
      m("main","Hi! This small app will give you a root-backdoor via telnet for Nokia 8110s with firmware v16+ --> Select/Enter will toggle the server on/off. While enabled the IP to connect to is showed on screen. Connections are possible from other devices on same network or to localhost if your in an adb-shell. Have Fun! speeduploop"),
      m("h3", m("a", { href: "#mview" }, "Enter!"))
    ])
};

let running=false;
let port=23;
let cmd='busybox telnetd -p ' + port + ' -l /system/bin/sh';
let kill="busybox pkill -f '" + cmd + "'";

window.onunload = () => { if(running) navigator.engmodeExtension.startUniversalCommand(kill, true); }

const mview = {
  oncreate: () => {
    document.querySelector("button").focus();
  },
  view: () =>
    m("main", [
      m("h1", "telnetd backdoor"),
      m("h3", "by speeduploop"),
      m("hr"),
      m("button",
        {
          onclick: () => {
            if(!running) {
              navigator.engmodeExtension.startUniversalCommand(cmd, true);
              running = true;
            } else {
              navigator.engmodeExtension.startUniversalCommand(kill, true);
              running = false;
            }
          }
        },
      (running == true ? "stop" : "start") + " server"),
      m("h3", running ? ">>> " + navigator.mozWifiManager.connectionInformation.ipAddress + (port != 23 ? " : " + port : "") : ""),
    ])
};

m.route(document.body, "splash", {
  splash: splash,
  intro: intro,
  mview: mview
});
